﻿namespace Exercise06
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labelTitle = new System.Windows.Forms.Label();
            this.labelInsertMoney = new System.Windows.Forms.Label();
            this.labelExactChangeReq = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.pictureBoxRegular = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonNickel = new System.Windows.Forms.Button();
            this.buttonDime = new System.Windows.Forms.Button();
            this.buttonQuarter = new System.Windows.Forms.Button();
            this.buttonHalfDollar = new System.Windows.Forms.Button();
            this.labelInsertCoins = new System.Windows.Forms.Label();
            this.buttonReturnMoney = new System.Windows.Forms.Button();
            this.buttonEjectRegular = new System.Windows.Forms.Button();
            this.buttonEjectOrange = new System.Windows.Forms.Button();
            this.buttonEjectLemon = new System.Windows.Forms.Button();
            this.labelTotalChange = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRegular)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(42, 9);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(376, 25);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "The Amazing SODA Vending Machine";
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelInsertMoney
            // 
            this.labelInsertMoney.AutoSize = true;
            this.labelInsertMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInsertMoney.Location = new System.Drawing.Point(308, 71);
            this.labelInsertMoney.Name = "labelInsertMoney";
            this.labelInsertMoney.Size = new System.Drawing.Size(133, 26);
            this.labelInsertMoney.TabIndex = 1;
            this.labelInsertMoney.Text = "Please insert 35 cents\r\nfor a can of soda";
            // 
            // labelExactChangeReq
            // 
            this.labelExactChangeReq.AutoSize = true;
            this.labelExactChangeReq.ForeColor = System.Drawing.Color.Red;
            this.labelExactChangeReq.Location = new System.Drawing.Point(308, 97);
            this.labelExactChangeReq.Name = "labelExactChangeReq";
            this.labelExactChangeReq.Size = new System.Drawing.Size(117, 13);
            this.labelExactChangeReq.TabIndex = 2;
            this.labelExactChangeReq.Text = "exact change required*";
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(308, 394);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(44, 13);
            this.labelTotal.TabIndex = 3;
            this.labelTotal.Text = "Total: ";
            // 
            // pictureBoxRegular
            // 
            this.pictureBoxRegular.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxRegular.BackgroundImage")));
            this.pictureBoxRegular.Location = new System.Drawing.Point(12, 71);
            this.pictureBoxRegular.Name = "pictureBoxRegular";
            this.pictureBoxRegular.Size = new System.Drawing.Size(271, 85);
            this.pictureBoxRegular.TabIndex = 4;
            this.pictureBoxRegular.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 179);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(271, 85);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 290);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(271, 85);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // buttonNickel
            // 
            this.buttonNickel.Location = new System.Drawing.Point(315, 179);
            this.buttonNickel.Name = "buttonNickel";
            this.buttonNickel.Size = new System.Drawing.Size(56, 58);
            this.buttonNickel.TabIndex = 7;
            this.buttonNickel.Text = "Nickel";
            this.buttonNickel.UseVisualStyleBackColor = true;
            this.buttonNickel.Click += new System.EventHandler(this.buttonNickel_Click);
            // 
            // buttonDime
            // 
            this.buttonDime.Location = new System.Drawing.Point(377, 179);
            this.buttonDime.Name = "buttonDime";
            this.buttonDime.Size = new System.Drawing.Size(56, 58);
            this.buttonDime.TabIndex = 8;
            this.buttonDime.Text = "Dime";
            this.buttonDime.UseVisualStyleBackColor = true;
            this.buttonDime.Click += new System.EventHandler(this.buttonDime_Click);
            // 
            // buttonQuarter
            // 
            this.buttonQuarter.Location = new System.Drawing.Point(315, 243);
            this.buttonQuarter.Name = "buttonQuarter";
            this.buttonQuarter.Size = new System.Drawing.Size(56, 58);
            this.buttonQuarter.TabIndex = 9;
            this.buttonQuarter.Text = "Quarter";
            this.buttonQuarter.UseVisualStyleBackColor = true;
            this.buttonQuarter.Click += new System.EventHandler(this.buttonQuarter_Click);
            // 
            // buttonHalfDollar
            // 
            this.buttonHalfDollar.Location = new System.Drawing.Point(377, 243);
            this.buttonHalfDollar.Name = "buttonHalfDollar";
            this.buttonHalfDollar.Size = new System.Drawing.Size(56, 58);
            this.buttonHalfDollar.TabIndex = 10;
            this.buttonHalfDollar.Text = "Half Dollar";
            this.buttonHalfDollar.UseVisualStyleBackColor = true;
            this.buttonHalfDollar.Click += new System.EventHandler(this.buttonHalfDollar_Click);
            // 
            // labelInsertCoins
            // 
            this.labelInsertCoins.AutoSize = true;
            this.labelInsertCoins.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInsertCoins.Location = new System.Drawing.Point(312, 143);
            this.labelInsertCoins.Name = "labelInsertCoins";
            this.labelInsertCoins.Size = new System.Drawing.Size(129, 13);
            this.labelInsertCoins.TabIndex = 11;
            this.labelInsertCoins.Text = "Insert coins (free $$!)";
            // 
            // buttonReturnMoney
            // 
            this.buttonReturnMoney.Location = new System.Drawing.Point(315, 319);
            this.buttonReturnMoney.Name = "buttonReturnMoney";
            this.buttonReturnMoney.Size = new System.Drawing.Size(118, 25);
            this.buttonReturnMoney.TabIndex = 13;
            this.buttonReturnMoney.Text = "Refund Coins";
            this.buttonReturnMoney.UseVisualStyleBackColor = true;
            this.buttonReturnMoney.Click += new System.EventHandler(this.buttonReturnMoney_Click);
            // 
            // buttonEjectRegular
            // 
            this.buttonEjectRegular.Location = new System.Drawing.Point(88, 394);
            this.buttonEjectRegular.Name = "buttonEjectRegular";
            this.buttonEjectRegular.Size = new System.Drawing.Size(61, 46);
            this.buttonEjectRegular.TabIndex = 14;
            this.buttonEjectRegular.Text = "Eject Regular";
            this.buttonEjectRegular.UseVisualStyleBackColor = true;
            this.buttonEjectRegular.Click += new System.EventHandler(this.buttonEjectRegular_Click);
            // 
            // buttonEjectOrange
            // 
            this.buttonEjectOrange.Location = new System.Drawing.Point(155, 394);
            this.buttonEjectOrange.Name = "buttonEjectOrange";
            this.buttonEjectOrange.Size = new System.Drawing.Size(61, 46);
            this.buttonEjectOrange.TabIndex = 15;
            this.buttonEjectOrange.Text = "Eject Orange";
            this.buttonEjectOrange.UseVisualStyleBackColor = true;
            this.buttonEjectOrange.Click += new System.EventHandler(this.buttonEjectOrange_Click);
            // 
            // buttonEjectLemon
            // 
            this.buttonEjectLemon.Location = new System.Drawing.Point(222, 394);
            this.buttonEjectLemon.Name = "buttonEjectLemon";
            this.buttonEjectLemon.Size = new System.Drawing.Size(61, 46);
            this.buttonEjectLemon.TabIndex = 16;
            this.buttonEjectLemon.Text = "Eject Lemon";
            this.buttonEjectLemon.UseVisualStyleBackColor = true;
            this.buttonEjectLemon.Click += new System.EventHandler(this.buttonEjectLemon_Click);
            // 
            // labelTotalChange
            // 
            this.labelTotalChange.AutoSize = true;
            this.labelTotalChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalChange.Location = new System.Drawing.Point(379, 387);
            this.labelTotalChange.Name = "labelTotalChange";
            this.labelTotalChange.Size = new System.Drawing.Size(54, 25);
            this.labelTotalChange.TabIndex = 17;
            this.labelTotalChange.Text = "0.00";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 654);
            this.Controls.Add(this.labelTotalChange);
            this.Controls.Add(this.buttonEjectLemon);
            this.Controls.Add(this.buttonEjectOrange);
            this.Controls.Add(this.buttonEjectRegular);
            this.Controls.Add(this.buttonReturnMoney);
            this.Controls.Add(this.labelInsertCoins);
            this.Controls.Add(this.buttonHalfDollar);
            this.Controls.Add(this.buttonQuarter);
            this.Controls.Add(this.buttonDime);
            this.Controls.Add(this.buttonNickel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBoxRegular);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.labelExactChangeReq);
            this.Controls.Add(this.labelInsertMoney);
            this.Controls.Add(this.labelTitle);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRegular)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label labelInsertMoney;
        private System.Windows.Forms.Label labelExactChangeReq;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.PictureBox pictureBoxRegular;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button buttonNickel;
        private System.Windows.Forms.Button buttonDime;
        private System.Windows.Forms.Button buttonQuarter;
        private System.Windows.Forms.Button buttonHalfDollar;
        private System.Windows.Forms.Label labelInsertCoins;
        private System.Windows.Forms.Button buttonReturnMoney;
        private System.Windows.Forms.Button buttonEjectRegular;
        private System.Windows.Forms.Button buttonEjectOrange;
        private System.Windows.Forms.Button buttonEjectLemon;
        private System.Windows.Forms.Label labelTotalChange;
    }
}

